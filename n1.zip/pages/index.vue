<template>
  <div class="page-home">
    <div class="container">
      <h1>
        Nuxt site
      </h1>

      <div class="stunningPortfolios">
        <div class="header">
          <h2>Stunning Portfolios</h2>
          <p>Please visit some of the projects we have designed and developed for our clients</p>
        </div>
        <div class="section stunningPortfolios-block">
          <nuxt-link
            class="section-col portfolio-link"
            to
            :style="{'background-image': 'url(' + require('~/assets/images/portfolio/Foundry360.jpg') + ')' }"
          >
            <div>
              <h4>Foundry 360</h4>
              <p>Foundry / Wordpress / Websites</p>
            </div>
            </nuxt-link>
          <nuxt-link
            class="section-col portfolio-link"
            to
            :style="{'background-image': 'url(' + require('~/assets/images/portfolio/Foundry360.jpg') + ')' }"
          >
            <div>
              <h4>Foundry 360</h4>
              <p>Foundry / Wordpress / Websites</p>
            </div>
          </nuxt-link>
          <nuxt-link
            class="section-col portfolio-link"
            to
            :style="{'background-image': 'url(' + require('~/assets/images/portfolio/Foundry360.jpg') + ')' }"
          >
            <div>
              <h4>Foundry 360</h4>
              <p>Foundry / Wordpress / Websites</p>
            </div>
          </nuxt-link>
          <nuxt-link
            class="section-col portfolio-link"
            to
            :style="{'background-image': 'url(' + require('~/assets/images/portfolio/Foundry360.jpg') + ')' }"
          >
            <div>
              <h4>Foundry 360</h4>
              <p>Foundry / Wordpress / Websites</p>
            </div>
          </nuxt-link>
        </div>
        <div class="section">
          <div class="section-col">
            <nuxt-link to="/projects" class="btn" title="Projects">More Projects</nuxt-link>
          </div>
        </div>
        <script src='/home.js' /> <!-- добавление скрипта в тело страницы -->
      </div>

    </div>
  </div>
</template>

<script>
export default {
  head: {
    title: 'Software development company Rightapplication',
    meta: [
      {
        hid: "description",
        name: "description",
        content:
          '"Wide spectrum of IT services ranging from consulting, web application design, development, server migration and graphic designing to offshore IT Staffing.'
      },
      {
        hid: "keywords",
        name: "keywords",
        content:
          "graphic design, UX/IX design, Front-end development, Ecommerce, Back-End development, Mobile development, Content management Integration, Server migration, Consulting, Project management"
      }
    ],
    link: [{ rel: "canonical", href: "https://rightapplications.com" }],
    // script: [{ src: '/home.js' }] // добавление скрипта в head
  },
  components: {
  }
};
</script>

<style scoped>
.header  {
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
  text-align: center;
}
.section {
  width: 100%;
  max-width: 1280px;
  margin: 0 auto;
}
.container {
  max-width: none;
}
.header p {
  font-size: 18px;
}
.btn {
  display: inline-block;
  background-color: rgba(153, 51, 0, 1);
  border-radius: 6px;
  color: #fff;
  font-size: 13px;
  padding: 8px 25px;
  text-decoration: none;
}
.btn:hover {
  background-color: darkgreen;
  text-decoration: none;
}
.stunningPortfolios {
  background-color: #fff;
}
.stunningPortfolios-block {
  margin-bottom: 30px;
}
.portfolio-link,
.portfolio-link:hover {
  text-decoration: none;        
  transition: all 300ms ease-in-out;
}
.portfolio-link div {
	display: flex;
	flex-direction: column;
	flex-wrap: nowrap;
  justify-content: center;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  transition: all 300ms ease-in-out;
}
.portfolio-link:hover div {
  background-color: rgba(0, 0, 0, 0.7);
  transition: all 300ms ease-in-out;
}
.portfolio-link h4,
.portfolio-link p {
  color: #fff;
  font-weight: 400;
}
.portfolio-link:hover h4,
.portfolio-link:hover p {
  text-decoration: none;
  color: #fff;
}
.portfolio-link h4 {
  font-size: 25px;
}
.portfolio-link p {
  font-style: italic;
}
@media (min-width: 768px) {
  .stunningPortfolios-block {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: space-between;
  }
  .stunningPortfolios-block a.section-col {
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    width: 25%;
    display: block;
    padding: 0;
    margin: 0 20px;
  }
  .stunningPortfolios-block .section-col {
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
  .stunningPortfolios {
    padding-top: 10px;
  }
  .stunningPortfolios .header {
    margin-bottom: 25px;
  }
  .stunningPortfolios .header h2 {
    margin-bottom: 15px;
  }
  .stunningPortfolios .btn {
    float: right;
    margin-right: 20px;
  }
}
@media (min-width: 767px) {
}
</style>
