<template>
  <div class="page-home">
    <div class="container">
      <h1>
        Nuxt site
      </h1>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style scoped>
</style>
