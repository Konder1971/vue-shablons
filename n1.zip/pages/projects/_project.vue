<template>
  <div class="project">
    <div class="section">
      <div class="section-col">
        <h1>Project</h1>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Project',
  head: {
    title: "",
    meta: [
      {
        hid: "description",
        name: "description",
        content: ''
      },
      {
        hid: "keywords",
        name: "keywords",
        content: ""
      }
    ],
    link: [{ rel: "canonical", href: "" }],
  }, 
}
</script>

<style scoped>

</style>