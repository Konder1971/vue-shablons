<template>
  <div class="navigation">
    <div class="section">
      <div class="section-col container">
        <Logo />
        <nav>
          <ul>
            <!--<li v-for="navigation in navigations" :key="navigation">{{ navigation.link }}</li>-->
            <li>
              <nuxt-link exact no-prefect to="/" title>Home</nuxt-link>
            </li>
            <li>
              <nuxt-link to="/projects" title>Projects</nuxt-link>
            </li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</template>

<script>
import Logo from "~/components/logo";
export default {
  head: {
    script: [{ src: "/main.js" }]
  },
  data() {
    return {
      navigations: [
        { link: "link 1" },
        { link: "link 2" },
        { link: "link 3" },
        { link: "link 4" },
        { link: "link 5" }
      ]
    };
  },
  components: {
    Logo
  }
}
</script>

<style scoped>
.section {
  width: 100%;
  max-width: 1240px;
  margin: 0 auto;
}
.section .container {
  max-width: none;
}
.navigation {
  background-color: #fff;
  box-shadow: rgba(0, 0, 0, 0.05) 0 4px 2px -2px;
  border-bottom: 1px solid #dadce0;
  position: fixed;
  z-index: 99;
  top: 0;
  width: 100%;
}
.home-navigation {
  background-color: #b00!important;
}
.section-col {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: center;
  height: 86px;
}
ul,
li {
  list-style: none;
  padding: 0;
  margin: 0;
}
ul {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-end;
  align-items: center;
  align-content: flex-start;
}
nav a {
  display: block;
  margin-left: 30px;
  font-weight: 300;
  color: #222;
  font-weight: 500;
  text-decoration: none;
}
nav a:hover,
nav a.nuxt-link-exact-active{
  color: darkgreen;
  text-decoration: none;
}
nav a.active {
  cursor: default;
}
@media (min-width: 768px) {
  .navigation.fixed .section-col {
    height: 60px;
    transition: all 300ms ease-in-out;
  }
}
</style>