<template>
  <nuxt-link to="/" title="" class="logo">
    <img src="~/assets/images/logo_rightapplications.png" alt="" />
    <em></em>
    <span>Right<br />applications</span>
  </nuxt-link>
</template>

<style scoped>
.logo {
  display: flex;
	flex-direction: row;
	flex-wrap: nowrap;
	justify-content: flex-start;
	align-content: center;
  text-transform: uppercase;
  color: #000;
  text-decoration: none;
}
.logo:hover {
  color: darkgreen;
  text-decoration: none;
}
.logo img {
  width: auto;
  float: left;
  transition: all 300ms ease-in-out;
}
em {
  background-color: darkgreen;
  width: 2px;
  margin: 0 15px;
  transition: all 300ms ease-in-out;
}
span {
  text-transform: uppercase;
  font-size: 14px;
  font-weight: 600;
  transition: all 300ms ease-in-out;
  display: flex;
	flex-direction: column;
	flex-wrap: nowrap;
	justify-content: center;
}
@media (min-width: 768px) {
  .logo img {
    height: 40px;
  }
  .navigation.fixed .logo img {
    height: 33px;
  }
  .navigation.fixed em {
    margin: 0 10px;
  }
  .navigation.fixed span {
    font-size: 12px;
  }
}
</style>