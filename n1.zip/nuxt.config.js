
export default {
  /*
  ** Nuxt rendering mode
  ** See https://nuxtjs.org/api/configuration-mode
  */
  mode: 'universal',
  /*
  ** Nuxt target
  ** See https://nuxtjs.org/api/configuration-target
  */
  target: 'server',
  /*
  ** Headers of the page
  ** See https://nuxtjs.org/api/configuration-head
  */
  head: {
   // title: process.env.npm_package_name || '', типовой title
   meta: [
    { charset: 'utf-8' },
    { name: 'theme-color', content: '#000000'},
    { name: 'viewport', content: 'width=device-width, initial-scale=1' },
    // { hid: 'description', name: 'description', content: process.env.npm_package_description || '' }, типовой description
    { hid: 'keywords', name: 'keywords', content: '' }, 
    { hid: 'robots', name: 'robots', content: 'noindex, nofollow' } // запрет на индексацию
  ],
  link: [
    { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
    { rel: 'stylesheet', href: 'https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,623;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,623;1,700;1,800;1,900&display=swap' }
  ]
  },
  /*
  ** Global CSS
  */
  css: [
    //'~assets/css/bootstrap-grid.css' // подключение css папку assets
    '~/static/css/bootstrap-grid.css' // подключение css через папку static
  ],
  /*
  ** Plugins to load before mounting the App
  ** https://nuxtjs.org/guide/plugins
  */
  plugins: [
  ],
  /*
  ** Auto import components
  ** See https://nuxtjs.org/api/configuration-components
  */
  components: true,
  /*
  ** Nuxt.js dev-modules
  */
  buildModules: [
  ],
  /*
  ** Nuxt.js modules
  */
  modules: [
    // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
  ],
  /*
  ** Axios module configuration
  ** See https://axios.nuxtjs.org/options
  */
  axios: {},
  /*
  ** Build configuration
  ** See https://nuxtjs.org/api/configuration-build/
  */
  build: {
  }
}
