var heig;
var heig = document.querySelector(".portfolio-link").offsetWidth;
document.querySelector(".portfolio-link div").style.height = heig + "px";
window.onresize = function(event) {
  var heig = document.querySelector(".portfolio-link").offsetWidth;
  document.querySelector(".portfolio-link div").style.height = heig + "px";
}
  
/*
window.onload = function() {
  var heig = document.querySelector(".portfolio-link").offsetWidth;
  document.querySelector(".portfolio-link").style.height = heig + "px";
  window.onresize = function(event) {
    var heig = document.querySelector(".portfolio-link").offsetWidth;
    document.querySelector(".portfolio-link").style.height = heig + "px";
  }
};
*/

/*
document.addEventListener('DOMContentLoaded', function() {
  var heig = document.querySelector(".portfolio-link").offsetWidth;
  document.querySelector(".portfolio-link").style.height = heig + "px";
}, false);
*/