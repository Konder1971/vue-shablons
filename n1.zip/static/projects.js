var hpeheight;
hpeheight = document.querySelectorAll(".pepic");
var hhpe = document.querySelector(".pepic").offsetWidth;
for (i = 0; i < hpeheight.length; i++) {
  hpeheight[i].style.height = hhpe + "px";
};
window.onresize = function(event) {
  var hhpe = document.querySelector(".pepic").offsetWidth;
  for (i = 0; i < hpeheight.length; i++) {
    hpeheight[i].style.height = hhpe + "px";
  }
}
/*
window.onload = function() {
  var hhpe = document.querySelector(".pepic").offsetWidth;
  for (i = 0; i < hpeheight.length; i++) {
    hpeheight[i].style.height = hhpe + "px";
  };
  window.onresize = function(event) {
    var hhpe = document.querySelector(".pepic").offsetWidth;
    for (i = 0; i < hpeheight.length; i++) {
      hpeheight[i].style.height = hhpe + "px";
    }
  }
}
*/

