import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Page from "../views/Page.vue";
import VueBlog from "../views/VueBlog.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "home",
    component: Home
  },
  {
    path: "/about",
    name: "about",
    component: () => import("../views/About.vue")
  },
  {
    path: '/recepts',
    name: 'recepts',
    component: () => import('../views/Recepts.vue')
  },
  {
    path: "/jscollection",
    name: "jscollection",
    component: () => import("../views/JsСollection.vue")
  },
  {
    path: "/page3coll",
    name: "page3coll",
    component: () => import("../views/Page3coll.vue")
  },
  {
    path: "/page",
    name: "page",
    component: Page,
    children: [
      {
        path: "/",
        name: "page",
        component: () => import("../views/pages/Pagecontent.vue"),
        meta: { title: "pagecontent" }
      },
      {
        path: "/content1",
        name: "content1",
        component: () => import("../views/pages/Content1.vue"),
        meta: { title: "Content1" }
      },
      {
        path: "/content2",
        name: "content2",
        component: () => import("../views/pages/Content2.vue"),
        meta: { title: "Content2" }
      },
      {
        path: "/content3",
        name: "content3",
        component: () => import("../views/pages/Content3.vue"),
        meta: { title: "Content3" }
      },
      {
        path: "/TablicaUmnojeniay",
        name: "/TablicaUmnojeniay",
        component: () => import("../views/pages/TablicaUmnojeniay.vue"),
        meta: { title: "/TablicaUmnojeniay" }
      }
    ]
  },
  {
    path: "/vueblog",
    name: "vueblog",
    component: VueBlog,
    children: [
      {
        path: "/",
        name: "vueblog",
        component: () => import("../vueblog/BlogHome.vue"),
        meta: { title: "/BlogHome" }
      },
      {
        path: "/counters",
        name: "counters",
        component: () => import("../vueblog/Counters.vue"),
        meta: { title: "/Counters" }
      },
      {
        path: "/changecontent",
        name: "changecontent",
        component: () => import("../vueblog/Changecontent.vue"),
        meta: { title: "/Changecontent" }
      },
      {
        path: "/cssclass",
        name: "/cssclass",
        component: () => import("../vueblog/CssClass.vue"),
        meta: { title: "/CssClass" }
      },
      {
        path: "/rabotasospiskomblog",
        name: "rabotasospiskomblog",
        component: () => import("../vueblog/RabotasospiskomBlog.vue"),
        meta: { title: "/RabotasoSpiskomBlog" }
      },
      {
        path: "/variantmenu",
        name: "variantmenu",
        component: () => import("../vueblog/VariantMenu.vue"),
        meta: { title: "/VaiantMenu" }
      },
      {
        path: "/ReplaceItems",
        name: "ReplaceItems",
        component: () => import("../vueblog/ReplaceItems.vue"),
        meta: { title: "ReplaceItems" }
      },
      {
        path: "/tabs",
        name: "tabs",
        component: () => import("../vueblog/Tabs.vue"),
        meta: { title: "/Tabs" }
      },
      {
        path: "/filters",
        name: "filters",
        component: () => import("../vueblog/Filters.vue"),
        meta: { title: "/Filters" }
      },
      {
        path: "/forms",
        name: "forms",
        component: () => import("../vueblog/Forms.vue"),
        meta: { title: "/Forms" }
      },
      {
        path: "/categoty-1",
        name: "categoty-1",
        component: () => import("../vueblog/Categoty-1.vue"),
        meta: { title: "/Categoty-1" }
      }
    ]
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
