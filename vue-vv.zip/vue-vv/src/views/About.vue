<template>
  <div class="about">
    <h1>This is an about page</h1>
    <hr>

    <h2>Filter DIV Elements</h2>
    <div id="myBtnContainer">
      <button
        class="btn active"
        @click="filterSelection('all')"
      >
        Show all
      </button>
      <button
        class="btn"
        @click="filterSelection('korob')"
      >
        Korob
      </button>
      <button
        class="btn"
        @click="filterSelection('cars')"
      >
        Cars
      </button>
      <button
        class="btn"
        @click="filterSelection('animals')"
      >
        Animals
      </button>
      <button
        class="btn"
        @click="filterSelection('fruits')"
      >
        Fruits
      </button>
      <button
        class="btn"
        @click="filterSelection('colors')"
      >
        Colors
      </button>
    </div>
    <div class="container">
      <div class="filterDiv cars">
        BMW
      </div>
      <div class="filterDiv korob">
        kr-1
      </div>
      <div class="filterDiv colors fruits">
        Orange
      </div>
      <div class="filterDiv cars">
        Volvo
      </div>
      <div class="filterDiv colors">
        Red
      </div>
      <div class="filterDiv korob">
        kr-2
      </div>
      <div class="filterDiv cars animals">
        Mustang
      </div>
      <div class="filterDiv colors">
        Blue
      </div>
      <div class="filterDiv animals">
        Cat
      </div>
      <div class="filterDiv korob">
        kr-3
      </div>
      <div class="filterDiv korob">
        kr-4
      </div>
      <div class="filterDiv animals">
        Dog
      </div>
      <div class="filterDiv fruits">
        Melon
      </div>
      <div class="filterDiv fruits animals">
        Kiwi
      </div>
      <div class="filterDiv fruits">
        Banana
      </div>
      <div class="filterDiv fruits">
        Lemon
      </div>
      <div class="filterDiv korob">
        kr-5
      </div>
      <div class="filterDiv animals">
        Cow
      </div>
    </div>

    <!--
    <h2>Мантры земных стихий</h2>
    <p>
      Работа с мантрами предполагает поэтапное освоение энергий различного уровня. Приведенные ниже мантры являются мантрами, которые применяются в программе Школы Йога Гуру Ар Сантэма на начальном уровне в практике
      <a href="/mantra-yoga-mantra-om.htm">мантра-йоги</a>. Данный перечень мантр даёт более плотный спектр энергий, что позволяет занимающимся за непродолжительный промежуток времени ощутить энергию этих мантр. А также, на более продвинутом этапе освоения мантра-йоги, прочувствовать отличительные свойства данных энергий и их влияние на физическую энергетическую и психологическую составляющую человека.
    </p>
    <table>
      <tr>
        <td width="67">Мантра</td>
        <td width="181">Цвет энергии</td>
        <td width="448">Значение</td>
      </tr>
      <tr>
        <td width="67">ЮМ</td>
        <td width="181">Тёмно коричневый</td>
        <td width="448">
          Стихия земли. Твёрдость костной системы.
          <br />Состояние внутренней твёрдости, стержня.
        </td>
      </tr>
      <tr>
        <td width="67">ДЭ</td>
        <td width="181">Светло коричневый</td>
        <td
          width="448"
        >Стихия земли. Пополнение микроэлементами органов. Структурирование&nbsp;тела, мягких тканей.</td>
      </tr>
      <tr>
        <td width="67">ХУМ</td>
        <td width="181">Синий шёлк</td>
        <td width="448">
          Стихия воды. Замена внутренних вод в организме.
          <br />Состояние плавности, текучести
        </td>
      </tr>
      <tr>
        <td width="67">ЦЮ</td>
        <td width="181">Светло красный, розовый</td>
        <td width="448">Возбуждение и нормализация эндокринной системы</td>
      </tr>
      <tr>
        <td width="67">АХ</td>
        <td width="181">Красный шёлк</td>
        <td width="448">
          Стихия огня. Чистка земных энергий.
          <br />Состояние энергичности, движения&hellip;
        </td>
      </tr>
      <tr>
        <td width="67">ЗЭЖ</td>
        <td width="181">
          Светло синий,
          <br />голубой
        </td>
        <td width="448">
          Стихия воздуха. Замена внутренних ветров в организме.
          <br />Состояние лёгкости
        </td>
      </tr>
      <tr>
        <td width="67">ИРИ</td>
        <td width="181">
          Светло голубой,
          <br />белёсый
        </td>
        <td width="448">Стихия эфира</td>
      </tr>
      <tr>
        <td width="67">БУХ</td>
        <td width="181">Светло зелёный</td>
        <td width="448">Стихия дерева (рост).</td>
      </tr>
      <tr>
        <td width="67">ОМ</td>
        <td width="181">Белый шёлк</td>
        <td width="448">
          Женская Вселенская энергия.
          <br />Присутствует везде, где происходит рождение, зачатие.
        </td>
      </tr>
    </table>
    -->
  </div>
</template>

<script>
export default {
  name: "About",
  methods: {}
};

/*
filterSelection("all")

function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("filterDiv");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}

// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
*/
</script>

<style scoped>
p {
  margin: 20px 0;
}

.filterDiv {
  float: left;
  background-color: #2196f3;
  color: #ffffff;
  width: 100px;
  line-height: 100px;
  text-align: center;
  margin: 2px;
  display: none;
}
.show {
  display: block;
}
.container {
  margin-top: 20px;
  overflow: hidden;
}
.btn {
  border: none;
  outline: none;
  padding: 12px 16px;
  background-color: #f1f1f1;
  cursor: pointer;
}
.btn:hover {
  background-color: #ddd;
}
.btn.active {
  background-color: #666;
  color: white;
}

table {
  margin: 0 auto 20px;
  padding: 0 20px;
  text-align: left;
}
table td {
  padding: 10px;
  border: 1px solid #333;
}
h2 + p {
  max-width: 1000px;
  margin: 8px auto 20px;
}
</style>

