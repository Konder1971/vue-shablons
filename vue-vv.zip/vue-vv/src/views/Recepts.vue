<template>
  <div class="container">
    <AddRecipe />
    <div class="columns">
      <RecipeList />
      <RecipeDetail />
    </div>
  </div>
</template>

<script>
import AddRecipe from '@/components/AddRecipe'
import RecipeDetail from '@/components/RecipeDetail'
import RecipeList from '@/components/RecipeList'

export default {
  name: 'Recepts',
  components: {
    AddRecipe, RecipeList, RecipeDetail
  },
  data() {
    return {
      reciper: []
    }
  }
}
</script>

<style>
  .center {
    text-align: center;
  }
  .container {
    max-width: 1000px;
    margin: 0 auto 40px;
  }
  .columns {
    display: flex;
  }
  .detail, .list {
    width: 50%;
    border: 1px solid #ccc;
  }
  .list {
    border-right: 0;
  }
  .btn:disabled {
    cursor: not-allowed;
  }
  .btn.remove {
    background: #a00;
  }
  .btn.secondary{
    background: #ccc;
  }
</style>
