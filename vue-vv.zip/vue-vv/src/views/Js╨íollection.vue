<template>
  <div class="jscollection-container">
    <h1>JavaScript Collection</h1>
    <hr>
  </div>
</template>

<script>
export default {
  name: 'Jscollection',
  components: {
    //jcscontent, jcssidebar
  }
}
</script>

<style scoped>

</style>