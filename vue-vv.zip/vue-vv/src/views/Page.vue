<template>
  <div class="page">
    <sidebarpage />
    <div class="contentpage">
      <router-view />
    </div>
  </div>
</template>

<script>
import sidebarpage from "@/views/pages/Sidebarpage.vue"

export default {
  name: "Page",
  components: {
    sidebarpage,
  }
};
</script>

<style scoped>
  html body {
    background-color: #f7f9fa!important;
  }
  .page {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: center;
    margin: 0 auto;
    max-width: 1400px;
    padding: 0 30px 20px;
  }
  .sidebarpage {
    width: 30%;
  }
  .contentpage {
    width: 70%;
    padding: 17px 20px 20px 20px;
    background-color: #f8f8f8;
    text-align: left
  }
</style>

<style>
  .page .sidebarpage h2 {
    color: #fff;
    font-size: 30px;
    margin-bottom: 15px;
  }
</style>