<template>
  <div class="sidebarpage">
    <h2>Sidebar</h2>
    <div class="sidebarMenu">
      <router-link
        :key="link.url"
        tag="li"
        v-for="link in links"
        :to="link.url"
        exact="link.exact"
      >
        <a href="#">{{ link.title }}</a>
      </router-link>
    </div>
  </div>
</template>

<script>
export default {
  name: "Sidebarpage",
  data() {
    return {
      links: [
        { title: "Conent 1", url: "content1" },
        { title: "Conent 2", url: "content2" },
        { title: "Conent 3", url: "content3" },
        { title: "Таблица умножения", url: "TablicaUmnojeniay" }
      ]
    };
  }
};
</script>

<style scoped>
  .sidebarpage {
    background-color: #35495E;
    padding: 20px;
  }
  .sidebarpage h2 {
    text-align: center;
  }
  .sidebarMenu {
    padding: 10px;
    background-color: #222;
  }
  .sidebarpage ul, .sidebarpage li {
    list-style: none;
    padding: 0;
    margin: 0;
    text-align: left
  }
  .sidebarpage li {
    margin-bottom: 10px;
  }
  .sidebarpage a {
    color: #fff;
    font-weight: bold;
    font-size: 20px;
    text-decoration: none;
  }
  .sidebarpage a:hover,
  .sidebarpage li.router-link-exact-active a {
    color: #42b983;
  }
  .sidebarpage li:last-child {
    margin-bottom: 0;
  }
</style>