<template>
  <div class="content">
    <h1>Contaent 2</h1>
    <hr>
    <p>
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Atque esse ab, aperiam dolorem laudantium ipsum nisi.
      Est expedita nesciunt rerum, laboriosam qui alias velit minima voluptatibus repellendus dolor corrupti vel,
      ut iste esse temporibus libero. Dignissimos sed saepe sequi accusantium voluptates veritatis possimus eaque?
      Illo quisquam ipsum repudiandae minima sunt!
    </p>
    <p>
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Atque esse ab, aperiam dolorem laudantium ipsum nisi.
      Est expedita nesciunt rerum, laboriosam qui alias velit minima voluptatibus repellendus dolor corrupti vel,
      ut iste esse temporibus libero. Dignissimos sed saepe sequi accusantium voluptates veritatis possimus eaque?
      Illo quisquam ipsum repudiandae minima sunt!
    </p>
  </div>
</template>

<script>
export default {
  name: "Content2"
};
</script>

<style scoped>
</style>