<template>
  <div class="content">
    <h1>Home Blog Page</h1>

    
    <transition-group
      name="list"
      tag="p"
    >
      <span
        v-for="item in items"
        :key="item"
        class="list-item"
      >{{ item }}</span>
    </transition-group>
    <button @click="add">
      Добавить
    </button>
    <button @click="remove">
      Удалить
    </button>

    <hr>

    <div class="counter">
      <h3>{{ counterTitle }} = {{ counter }} | {{ counter2 }}</h3>
      <p>Результат: {{ resultcounter }}</p>
      <p>
        <button @click="counterPlus(4, 'Увеличен на 4', $event)">
          Увеличить на + 4
        </button>
        <button @click="counterPlus(10, 'Увеличен на 10', $event)">
          Увеличить на + 10
        </button>
        <button @click="counterMinus(3, 'Уменьшен на 3', $event)">
          Уменьшить на - 3
        </button>
        <button @click="counterReset">
          Сбросить на 0
        </button>
      </p>
      <p>
        <button @mouseover="counter2++">
          Add Counter2 Hover
        </button>
      </p>
    </div>
    <hr>

    <p>
      Перейти на сайт
      <a
        :href="urlGoogle"
        target="_blank"
      >Google</a>
      +
      <a
        href="https://google.com"
        class="googlelink"
        @click.prevent="isActive = !isActive"
        :class="blackWhait"
      >Запретили переход по ссылке - Кликай!</a>
    </p>
    <hr>

    <p v-if="isOk">
      Выводим Это если значение isOk = true
    </p>
    <hr>

    <p>
      <input
        type="text"
        v-model.lazy="inputValue"
      >
      <span>{{ inputValue }}</span>
    </p>
    <hr>

    <div v-html="vivodhtml" />
    <hr>

    <div>
      <h3>Смена отображения контента через v-if</h3>
      <p>v-if стирает элементы из DOM</p>
      <template v-if="isVisible">
        <h3>Header 111 Vis 111</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
          ducimus quidem illo rerum impedit fuga, corrupti dignissimos, maiores quo eos perspiciatis
          ex quasi dolore recusandae beatae consequuntur?
        </p>
      </template>
      <template v-else>
        <h3 style="color: #fff;">
          Header 222 Vis 222
        </h3>
        <p style="color: #fff;">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
          ducimus quidem illo rerum impedit fuga, corrupti dignissimos, maiores quo eos perspiciatis
          ex quasi dolore recusandae beatae consequuntur?
        </p>
      </template>
      <button @click="isVisible = !isVisible">
        Сменить отображения контента
      </button>
    </div>
    <hr>

    <div>
      <h3>Смена отображения контента через v-show</h3>
      <p>v-show не стирает элементы из DOM</p>
      <div v-show="isVisibles">
        <h3>Header 333 Vis 333</h3>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
          ducimus quidem illo rerum impedit fuga, corrupti dignissimos, maiores quo eos perspiciatis
          ex quasi dolore recusandae beatae consequuntur?
        </p>
      </div>
      <div v-show="!isVisibles">
        <h3 style="color: #00f;">
          Header 444 Vis 444
        </h3>
        <p style="color: #00f;">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
          ducimus quidem illo rerum impedit fuga, corrupti dignissimos, maiores quo eos perspiciatis
          ex quasi dolore recusandae beatae consequuntur?
        </p>
      </div>
      <button @click="isVisibles = !isVisibles">
        Сменить отображения контента
      </button>
    </div>
    <hr>

    <div>
      <h3>Работа с классами</h3>
      <h4>Кликните на круг для изменения цвета заливки</h4>
      <div class="t">
        <div
          class="circle"
          @click="isActive1 = !isActive1"
          :class="{ 'bc1' : isActive1, 'bc2' : !isActive1 }"
        />
        <div>
          <h4>Аналогичный вариант через computed</h4>
          <div
            class="circle"
            @click="isActive2 = !isActive2"
            :class="bkcolor"
          />
        </div>
      </div>
    </div>
    <hr>
  </div>
</template>

<script>
export default {
  name: "Blogcontent",
  data() {
    return {
      items: [1, 2, 3, 4, 5, 6, 7, 8, 9],
      nextNum: 10,

      counterTitle: "Счетчик",
      counter: 0,
      counter2: 0,
      isOk: true,
      urlGoogle: "https://google.com",
      inputValue: "",
      isActive: false,
      vivodhtml: "<p>Это вывод <strong>html</strong></p>",
      isVisible: true,
      isVisibles: true,
      isActive1: false,
      isActive2: false
    };
  },
  methods: {

    randomIndex: function() {
      return Math.floor(Math.random() * this.items.length);
    },
    add: function() {
      this.items.splice(this.randomIndex(), 0, this.nextNum++);
    },
    remove: function() {
      this.items.splice(this.randomIndex(), 1);
    },

    counterPlus: function(num, str, event) {
      this.counter += num;
      this.counterTitle = str;
      if (num === 4) {
        event.target.style.color = "blue";
      } else if (num === 10) {
        event.target.style.color = "red";
      }
    },
    counterMinus: function(num, str, event) {
      this.counter -= num;
      this.counterTitle = str;
      if (num === 3) {
        event.target.style.color = "silver";
      }
    },
    counterReset() {
      this.counter = 0;
      event.target.style.color = "#42b983";
      this.counterTitle = "Счетчик";
    }
  },
  computed: {
    resultcounter: function() {
      return this.counter > 6 ? "Больше 6" : "Меньше 6";
    },
    blackWhait: function() {
      return {
        black: this.isActive,
        whait: !this.isActive
      };
    },
    bkcolor() {
      return {
        bc4: this.isActive2,
        bc3: !this.isActive2
      };
    }
  }
};
</script>

<style scoped>

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter, .list-leave-to /* .list-leave-active до версии 2.1.8 */ {
  opacity: 0;
  transform: translateY(30px);
}

.counter button {
  display: inline-block;
  margin-right: 4px;
}
.googlelink {
  color: #116149;
  font-size: 18px;
  text-decoration: none;
}
.black {
  color: #000;
}
.whait {
  color: #fff;
}

.t {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: center;
}
.circle,
.circle2 {
  width: 150px;
  height: 150px;
  margin: 0 auto;
  border-radius: 50%;
  border: 2px solid #ca092d;
  cursor: pointer;
}
.bc1 {
  background-color: #ca092d;
  border: 2px solid #000;
}
.bc2 {
  background-color: #2f68a1;
}
.bc3 {
  background-color: #07b717;
}
.bc4 {
  background-color: #35495e;
}
</style>
