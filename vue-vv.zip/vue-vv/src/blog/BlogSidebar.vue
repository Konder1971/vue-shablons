<template>
  <div class="blogsidebar">
    <h2>Категории</h2>
    <div class="sidebarMenu">
      <router-link 
        :key="link.url" 
        tag="li" 
        v-for="link in links" 
        :to="link.url" 
        exact="link.exact"
      >
        <a href="#">{{ link.title }}</a>
      </router-link>
    </div>
  </div>
</template>
<script>
export default {
  name: "Blogsiderbar",
  data() {
    return {
      links: [
        { title: "Варианты меню", url: "variantmenu" },
        { title: "Табы", url: "tabs" },
        { title: "Списки", url: "rabotasospiskomblog" },
        { title: "Фильтры", url: "filters" },
        { title: "Категория 1", url: "categoty-1" }
      ]
    }
  }
};
</script>

<style scoped>
.blogsidebar {
  background-color: #35495e;
  width: 340px;
  padding: 20px 30px 30px;
}
.blogsidebar h2 {
  color:#fff;
  text-align: center;
}
.sidebarMenu {
  padding: 18px 20px;
  background-color: #232323;
}
.blogsidebar ul,
.blogsidebar li {
  list-style: none;
  padding: 0;
  margin: 0;
}
.blogsidebar li {
  margin-bottom: 10px;
}
.blogsidebar a {
  color: #fff;
  font-weight: bold;
  font-size: 20px;
  text-decoration: none;
}
.blogsidebar a:hover,
.blogsidebar li.router-link-exact-active a {
  color: #42b983;
}
.blogsidebar li:last-child {
  margin-bottom: 0;
}
</style>