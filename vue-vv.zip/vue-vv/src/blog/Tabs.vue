<template>
  <div class="content">
    <h1>Табуляция</h1>

    <div class="tabs">
      <span>Tab 1</span>
      <span>Tab 2</span>
      <span>Tab 3</span>
      <span>Tab 4</span>
    </div>

    <div class="tabContent">
      <div class="tab1">
        <p>111 111 111</p>
      </div>
      <div class="tab2">
        <p>222 222 222</p>
      </div>
      <div class="tab3">
        <p>333 333 333</p>
      </div>
      <div class="tab4">
        <p>444 444 444</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Tabs"
};
</script>

<style scoped>
</style>