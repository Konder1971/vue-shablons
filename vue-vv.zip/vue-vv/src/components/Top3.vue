<template>
  <div class="top3">
    top 3<br>
    <img
      alt=""
      src="../assets/logo.png"
    >
  </div>
</template>
<script>
export default {
  name: "Top3"
};
</script>
<style scoped>
.top3 {
  background-color: #41205f;
  color: #fff;
  font-size: 13px;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
  padding: 5px 0;
}
.top3 img {
  width: 80px;
}
</style>