<template>
  <form
    class="form"
    @submit.prevent="submit"
  >
    <p>
      video тут - <a
        target="_blank"
        href="https://www.youtube.com/watch?v=Ix8wcwrnPns"
      >Добавить рецепт</a>
    </p>
    <h1>Добавить рецепт</h1>
    <div>
      <div class="input">
        <input
          type="text"
          placeholder="Название рецепта"
          v-model="title"
        >
      </div>
      <div class="input">
        <input
          type="text"
          placeholder="Описание рецепта"
          v-model="description"
        >
      </div>
    </div>

    <div class="buttons">
      <button
        class="btn"
        type="submit"
      >
        Создать
      </button>
      <button
        class="btn secondary"
        type="button"
      >
        Убрать форму
      </button>
    </div>
  </form>
</template>

<script>
export default {
  data() {
    return {
      title: '',
      description: ''
    }
  },
  /*
  methods: {
    submit() {
      const recipe = (
        title: this.title.trim(),
        description: this.description.trim(),
        id: Date.now().toString()
      )
    }
    this.title = this.description = ''
  }
  */
}
</script>

<style>
  .form {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 1rem;
    border: 1px solid #ccc;
    margin-bottom: 1rem;
  }
  .form h1 {
    margin: 10px 0;
  }
  .input {
    margin-bottom: 14px;
  }
  .input input {
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px 12px;
    width: 400px;
  }
  .buttons {
    width: 400px;
    display: flex;
    justify-content: space-around;
  }
</style>
