<template>
  <div class="top">
    top
  </div>
</template>

<script>
export default {
  name: "Top"
};
</script>

<style scoped>
.top {
  background-color: #000;
  color: #fff;
  line-height: 35px;
  font-size: 13px;
}
</style>