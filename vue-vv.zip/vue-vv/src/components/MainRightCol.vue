<template>
  <div class="mainrightcol">
    <h3>MainRightCol</h3>
  </div>
</template>

<script>
export default {
  name: "MainRightCol",
};
</script>

<style scoped>
</style>