<template>
  <div class="maincontainer">
    <h1>{{ msgH1 }}</h1>
    <MainContent msg-h2="Title H2 Page" />
  </div>
</template>

<script>
import MainContent from "@/components/MainContent.vue";

export default {
  name: "MainContainer",
  components: {
    MainContent
  },
  props: {
    msgH1: String
  }
};
</script>

<style scoped>
</style>