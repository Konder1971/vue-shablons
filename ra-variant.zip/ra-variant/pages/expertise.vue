<template>
  <div class="expertise">
    <BannerExpertise />

    <div class="expertise-blocks">
      <div class="technologies">
        <div class="header">
          <h2>Technologies</h2>
        </div>
        <div class="section">
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/icon-1.svg" alt="">
              </div>
              <div class="text">
                <h3>Front-end</h3>
                <p>
                  Javascript,
                  Typescript,
                  HTML/HTML5,
                  CSS/CSS3/SASS/LESS
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/icon-2.svg" alt="">
              </div>
              <div class="text">
                <h3>Back-end</h3>
                <p>
                  PHP, Java,
                  C#, MySQL,
                  PostgreSQL, SQLite,
                  Redis
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/icon-3.svg" alt="">
              </div>
              <div class="text">
                <h3>Frameworks/CMS</h3>
                <p>
                  WordPress, Joomla, Bitrix,
                  ModX, Yii2, jQuery/jQuery UI,
                  React, Vue, Express.js,
                  Node.js, Bootstrap
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="project-planning">
        <div class="header">
          <h2>Project planning</h2>
          <p>We bring our strategy and digital innovation to your product.</p>
        </div>
        <div class="section">
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_2.png" alt="">
              </div>
              <div class="text">
                <h3>BUSINESS IMMERSION</h3>
                <p>
                  We do our best work when we have a deep understanding of your business. We accomplish this through business immersion sessions, on-site visits, and interviews with your company and customers. A conversation with customers is just the start. Working with your team, we’ll build a prototype of our solution and use this during our interview to further validate our product. When we understand your business, competitors, customers, and values, then we can provide the most value.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_3.png" alt="">
              </div>
              <div class="text">
                <h3>CONSULTING & RESEARCH</h3>
                <p>
                  Software should be designed for the people using it. Rather than driving our decisions by assumptions, we research and interview real users in order to build products that matter. Whether the users are part of your organization or customers. Through surveys or onsite visits, we’ll identify the right people to interview. We work with you to identify your business opportunity, conduct user interviews, collect feedback and help you make the most informed business decisions.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_1.png" alt="">
              </div>
              <div class="text">
                <h3>OBJECTIVES & PLANNING</h3>
                <p>
                  We discuss the business objectives, identify potential customers and build a working understanding of the problem that we’re solving. We understand that clients expect a return on their investment. Working with your company we will build a strategy based on your business goals. We’ll set expectations regarding timelines, budget, and process. Our goal is help make you successful by continuously delivering great software. Remember: We’re your partner, not your vendor.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="user-friendly-design">
        <div class="header">
          <h2>User friendly design</h2>
          <p>Bring our strategy and digital innovation to your product.</p>
        </div>
        <div class="section">
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_4.png" alt="">
              </div>
              <div class="text">
                <h3>DESIGN RESEARCH</h3>
                <p>
                  Who are your users? What are their pains and needs? What are they trying to accomplish? These are the important questions we’ll answer. user-persona User Personas We create reliable and realistic representations of your key audience segments to help you understand your users. With all of the potential solutions, we’ll work as a team to share, discuss, and decide on the best solution. We’ll create a storyboard and step-by-step plan for our prototype.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_5.png" alt="">
              </div>
              <div class="text">
                <h3>USER EXPERIENCE</h3>
                <p>
                  We work with you to translate business goals into software requirements with measurable acceptance criteria. We’ll work from low to high-fidelity wireframes to shape the layout, design, and experience of your product. We craft smart and intuitive user experiences through a user-tested, data-driven design approach. With a prototype and real customer feedback, we have answered the important questions about our design. Now we can move into high-fidelity designs and product development.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_6.png" alt="">
              </div>
              <div class="text">
                <h3>RODUCT DESIGN</h3>
                <p>
                  Storytelling is the heart of any successful product. We’ll help create a product that helps users connect through that story. Unique, well branded and user-friendly interfaces are created based on research, wireframes and clients/users feedback. We create unique and personalized web experiences with custom illustrations photography and iconography designed to evoke emotion and narration. We understand that a well-made user interface not only keeps customers but convert them into new customers.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="product-development">
        <div class="header">
          <h2>Product development</h2>
          <p>From dashboards to APIs to customer-facing applications, we have the experience to bring your product to life.</p>
        </div>
        <div class="section">
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_7.png" alt="">
              </div>
              <div class="text">
                <h3>TECHNOLOGY CONSULTING</h3>
                <p>
                  Itransition’s technology expertise and automation strategy knowledge empower Right Applications to provide customers with the first-class consulting services, Analytics play an important role prior to development. At this stage the analyst researches your software product idea and its purpose, your company business-processes, potential competitors, and generates a plan to optimize your software result. Our software consultants, and analysts will provide expert help with any technology issues or/and tasks.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_8.png" alt="">
              </div>
              <div class="text">
                <h3>CUSTOM SOFTWARE DEVELOPMENT</h3>
                <p>
                  We produce custom-built solutions for a number of industries. We work with various databases and APIs, and implement scaling and integration with other services. Whether you are a start-up or an established business, we are ready to assist you at every stage of the software development life cycle — from conceptualization and consulting to development and support. We focus on helping of our clients to increase revenues and automate mission-critical workflows. A client brings their vision to us – we make it happen.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_9.png" alt="">
              </div>
              <div class="text">
                <h3>MOBILE APPLICATION DEVELOPMENT</h3>
                <p>
                  We offer extensive hands-on experience in development of incredibly feature-laden mobile applications for iOS, Android and Windows Phone, as well as HTML5 based mobile websites, helping businesses to make that pivotal shift from web to mobile. Our goal is developing engaging, user-friendly mobile applications, Our solutions are cost effective and optimized to your requirements. We aim to help your business create and launch an app that satisfies business needs, provides an intuitive user experience, and launches successfully to your specific audience.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_10.png" alt="">
              </div>
              <div class="text">
                <h3>CONTENT MANAGEMENT (CMS)</h3>
                <p>
                  Our experts have extensive experience in CMS web development services that enable us to offer various services including CMS set up and developments for websites, and mobile applications. Our CMS developers have vast expertise in several Open Source CMS platforms to build web solutions that can be as robust as enterprise level websites. We unite your development and operations into a single rapid deployment entity. We push cross-functionality of your company’s data to help your business do more in less time.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_11.png" alt="">
              </div>
              <div class="text">
                <h3>E-COMMERCE</h3>
                <p>
                  We have grown our business understanding and technology skills through a decade in web development to mature into a fully qualified vendor undertaking the most challenging ecommerce projects. Among the sectors we play in are retail, travel & leisure, financial services, gaming and gambling, professional services, and many more. Extensive experience in designing, developing and maintaining corporate management systems enable us to ensure most comprehensive support of your e-commerce driven business.
                </p>
              </div>
            </div>
          </div>
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_12.png" alt="">
              </div>
              <div class="text">
                <h3>MIGRATION AND SUPPORT</h3>
                <p>
                  Moving your IT environment from one point to another is a complex task that should not be left in the hands of the inexperienced. Our Migration Service (SMS) specialists will make it easier and faster for you to migrate thousands of on-premises workloads. We deliver professional maintenance and online support. Our affordable website maintenance solution offer peace-of-mind for clients who require frequent updates to their websites or software applications. Our friendly, experienced and helpful team are here to help you.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="development-outsourcing">
        <div class="header">
          <h2>Development outsourcing</h2>
          <p>Providing our customers with high quality diligence and responsibility, we are always looking forward to a long term relationship.</p>
        </div>
        <div class="section">
          <div class="section-col">
            <div class="block">
              <div class="icon">
                <img src="~assets/images/ei_13.png" alt="">
              </div>
              <div class="text">
                <p>
                  Outsourcing your Web Development Projects helps you in scaling your business manifold as you get to deliver more number of projects in a limited time and cost. Our expert Development teams ensure that your project quality is never compromised upon. We provide technical and software expertize across the world. We have created a seamless workflow with our experience team in web development and design, mobility and app development. We provide our client with the best and dedicated staff to serve their requirements. <nuxt-link to="#" title="">
                    Learn More
                  </nuxt-link>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="need-a-quote">
        <div class="section">
          <div class="section-col">
            <div class="text">
              <h2>Need a Quote?</h2>
              <nuxt-link class="btn" to="/request-a-quote" title="">
                Click Here
              </nuxt-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import BannerExpertise from '~/components/banners/bannerExpertise'
export default {
  components: {
    BannerExpertise
  },
  head: {
    title: 'Expertise',
    meta: [
      { hid: 'description', name: 'description', content: 'OUR SERVICES &amp; CAPABILITIES. We are fully committed to adding value to our client businesses in every stage – from planning to maintaining. Our design and development process is based on problem solving' },
      { hid: 'keywords', name: 'keywords', content: 'graphic design, UX/IX design, Front-end development, Ecommerce, Back-End development, Mobile development, Content management Integration, Server migration, Consulting, Project management' }
    ],
    link: [{ rel: 'canonical', href: 'https://rightapplications.com/expertise' }]
  }
}
</script>

<style scoped>
.expertise-blocks .header {
  margin-bottom: 20px;
}
.expertise-blocks .header p {
  color: #996;
  font-size: 18px;
  line-height: 24px;
  font-weight: 300;
  margin-top: 15px;
}
.expertise-blocks .section-col {
  margin-bottom: 20px;
}
.expertise-blocks .section-col h3 {
  color: #2e2834;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 7px;
  text-transform: uppercase;
}
.expertise-blocks .section-col p {
  color: #999;
  font-size: 14px;
  line-height: 21px;
  margin-bottom: 20px;
}
.expertise-blocks .section-col .block {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
}
.expertise-blocks .section-col .block img {
  margin-right: 20px;
}
.need-a-quote {
  text-align: center;
  padding-top: 10px;
}
.need-a-quote h2 {
  margin-bottom: 20px;
}
@media (min-width: 768px) {
  .expertise-blocks {
    padding-top: 60px;
    padding-bottom: 40px;
  }
  .expertise-blocks .technologies .section-col,
  .expertise-blocks .project-planning .section-col,
  .expertise-blocks .user-friendly-design .section-col,
  .expertise-blocks .product-development .section-col {
    width: 33.33333%;
  }
}
</style>
