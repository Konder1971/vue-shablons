<template>
  <div class="copyright">
    <p>© 2020 Rightapplications</p>
  </div>
</template>

<style scoped>
.copyright {
  font-size: 13px;
  color: #999;
}
</style>
