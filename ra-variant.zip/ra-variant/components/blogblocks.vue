<template>
  <div class="blogblocks">
    <div class="blogblock">
      <a class="post-pic" href="" title="">
        <img src="~assets/images/blog/javaScript-frameworks.jpg" alt="">
      </a>
      <h2><a href="" title="">Top 10 most popular JavaScript frameworks</a></h2>
      <div class="post-date">
        November 28, 2019
      </div>
      <p>
        After years of struggling with competitors and sometimes unflattering PR, JavaScript settled down as the primary language for web development but… the race keeps going. New JS frameworks and libraries – tools that make JavaScript more accessible and easier to use – pop up so often that choosing the one best suited to the job
      </p>
      <a href="" class="btn" title="">Continue Reading</a>
    </div>
  </div>
</template>

<script>
export default {
  components: {
  },
  head: {
    title: '',
    meta: [
      { hid: 'description', name: 'description', content: '' },
      { hid: 'keywords', name: 'keywords', content: '' }
    ],
    link: [{ rel: 'canonical', href: '' }]
  }
}
</script>

<style scoped>

</style>
