<template>
  <div class="bannerHome">
    <div class="section">
      <div class="section-col">
        Banner Home
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {
  }
}
</script>

<style scoped>

</style>
