<template>
  <div>
    <h5>
      Counter: {{ counter }}
    </h5>
  </div>
</template>

<script>
import { eventEmitter } from '~/assets/car.js'
export default {
  data () {
    return {
      counter: 0
    }
  },
  created () {
    eventEmitter.$on('counterUpdated', (num) => {
      this.counter += num
    })
  }
}
</script>

<style scoped>

</style>
