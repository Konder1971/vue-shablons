window.onload = function () {
  const h3 = document.createElement('h3')
  h3.textContent = 'Вложенные Циклы'
  h3.classList.add('h3')
  document.querySelector('.tablicaUmnojeniay').appendChild(h3)
/*
  const h2 = document.createElement('h2')
  h2.textContent = 'Таблица умножения'
  h2.classList.add('h2')
  document.querySelector('.tablicaUmnojeniay').appendChild(h2)

  const wh = document.createElement('div')
  wh.classList.add('wh')
  document.querySelector('.tablicaUmnojeniay').appendChild(wh)
  let whj = 0
  let whflag = 10
  let whstr = ''
  while (whj <= 10) {
    let whk = 0
    while (whk < 10) {
      if (whk < whflag) {
        whstr += ' 0 '
      } else {
        whstr += ' * '
      }
      whk++
    }
    whflag--
    whstr += '<br />'
    whj++
  }
  wh.innerHTML = whstr

  const btnOn = document.createElement('button')
  btnOn.textContent = 'Показать'
  document
    .querySelector('.tablicaUmnojeniay')
    .appendChild(btnOn)
    .classList.add('button', 'btn', 'btnOn')

  const btnOff = document.createElement('button')
  btnOff.textContent = 'Скрыть'
  document
    .querySelector('.tablicaUmnojeniay')
    .appendChild(btnOff)
    .classList.add('button', 'btn', 'btnOff')

  btnOn.onclick = function tabumnOn () {
    const tabumn = document.createElement('div')
    tabumn.classList.add('tabumn')
    document.querySelector('.tablicaUmnojeniay').appendChild(tabumn)
    for (let i = 1; i < 10; i++) {
      const blockumn = document.createElement('p')
      blockumn.classList.add('blockumn', `blockumn-${i}`)
      document.querySelector('.tabumn').appendChild(blockumn)
      for (let k = 1; k < 10; k++) {
        blockumn.innerHTML += `<span>${i}*${k}=${i * k}</span>`
      }
    }
    document.querySelector('.btnOn').disabled = true
  }

  btnOff.onclick = function tabumnOff () {
    document.querySelector('.btnOn').disabled = false
    document.querySelector('.tabumn').remove()
  }
  */
}
