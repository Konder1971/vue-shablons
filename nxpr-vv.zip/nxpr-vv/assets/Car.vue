<template>
  <div class="car">
    <h5>{{ carName }} | {{ reversName }}</h5>
    <p>Car Name: {{ carName }}</p>
    <p>Car Year: {{ carYear }}</p>
    <button
      class="btn"
      @click="changeName"
    >
      Change Mazda
    </button>
    <button
      class="btn"
      @click="changeFunc()"
    >
      Change Audi
    </button>
    <button
      class="btn"
      @click="updateCounter"
    >
      Update Counter
    </button>
  </div>
</template>

<script>
import { eventEmitter } from '~/assets/car.js'
export default {
  // props: ['carName', 'carYear'],
  props: {
    carName: String,
    carYear: Number,
    changeFunc: Function
  },
  computed: {
    reversName () {
      return this.carName
        .split('')
        .reverse()
        .join('')
    }
  },
  methods: {
    changeName () {
      this.carName = 'Mazda'
      this.$emit('nameCanged', this.carName)
    },
    updateCounter () {
      eventEmitter.$emit('counterUpdated', 3)
    }
  }
}
</script>

<style scoped>
.car {
  background-color: #f8f8f8;
  border: 2px solid darkgreen;
  border-radius: 10px;
  padding: 20px 20px;
  margin: 20px auto;
  text-align: left;
}
h4 {
  color: darkgreen;
  margin-bottom: 10px;
}
h5 {
  color: #222;
  margin-bottom: 10px;
}
p {
  margin-bottom: 5px;
}
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 8px 15px 10px;
  margin: 5px 10px 0 0;
  font-size: 18px;
  font-weight: 600;
}
button:hover {
  background-color: #850000;
  color: #fff;
}
</style>
