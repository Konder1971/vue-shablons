<template>
  <nuxt />
</template>

<script>
export default {
  layout: 'animationslayout'
}
</script>

<style scoped>

</style>
