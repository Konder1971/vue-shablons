<template>
  <div class="content">
    <h1>Передача параметров</h1>
    <hr>
    <h4>Parent: {{ carName }}</h4>
    <count />
    <p>Передача: параметров компоненту, и от дочернего компонента, и функции, связь дочерних компонентов, использование event emitter</p>
    <app-car
      :car-name="carName"
      :car-year="carYear"
      :change-func="changeNameToAudi"
      @nameCanged="carName = $event"
      @counterUpdated="counter = $event"
    />
  </div>
</template>

<script>
import Count from '~/assets/Count.vue'

export default {
  components: {
    Count
  },
  data () {
    return {
      carName: 'Ford',
      carYear: 2018
    }
  },
  methods: {
    changeNameToAudi () {
      this.carName = 'Audi'
    }
  }
}
</script>

<style scoped>
</style>
