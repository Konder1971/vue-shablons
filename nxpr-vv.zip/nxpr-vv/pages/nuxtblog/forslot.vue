<template>
  <div>
    <h4>{{ title }}</h4>
    <p>{{ text }}</p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      title: 'Title for slot',
      text: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Cum earum ad nam maxime repellendus nesciunt eum corporis eius laborum enim!'
    }
  }
}
</script>

<style scoped>
</style>
