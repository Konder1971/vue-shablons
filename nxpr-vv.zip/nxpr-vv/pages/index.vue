<template>
  <div class="homeCont">
    <h1>
      My Nuxt.js Project
    </h1>
    <h3>Сейчас {{ data }}</h3>
    <h3 v-if="Math.random() > 0.5">
      Случайное число > 0.5
    </h3>
    <h3 v-else>
      Случайное число Меньше-равно 0.5
    </h3>
  </div>
</template>

<script>
export default {
  data () {
    return {
      data: new Date().toLocaleString()
    }
  },
  mounted () {
    setInterval(() => {
      this.updateDate()
    }, 1000)
  },
  methods: {
    updateDate () {
      this.data = new Date().toLocaleString()
    }
  }
}
</script>

<style scoped>
.homeCont {
  background-image: linear-gradient(#FFB503 5%, #FF7500 95%);
  margin-left: -20%;
  margin-right: -20%;
  padding: 40px 20px;
}
.homeCont h1 {
  margin: 20px 0;
}
.homeCont h3 {
  margin: 0 0 20px;
}
</style>
