<template>
  <div class="tech">
    <h2>{{ $route.params.id }}</h2>
    <h3>Technologies: </h3>
    <p>Descripnions: </p>
    <p>
      <nuxt-link to="/technologies">
        to Back
      </nuxt-link>
    </p>
  </div>
</template>

<script>
export default {
}
</script>
