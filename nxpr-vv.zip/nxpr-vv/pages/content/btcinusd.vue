<template>
  <div class="container">
    <h3 class="text-center">
      Cryptocurrency Pricing
    </h3>
    <p>
      Статья тут:
      <a
        target="_blank"
        href="https://webdevblog.ru/kak-ispolzovat-vue-js-i-axios-dlya-otobrazheniya-dannyh-iz-api/"
      >https://webdevblog.ru/kak-ispolzovat-vue-js-i-axios-dlya-otobrazheniya-dannyh-iz-api/</a>
    </p>

    <div v-for="(result, index) in results" :key="index" class="columns medium-4">
      <div class="card">
        <div class="card-section">
          <p>{{ index }}</p>
        </div>
        <div class="card-divider">
          <p>$ {{ result.USD }}</p>
        </div>
        <div class="card-section">
          <p>&#8364; {{ result.EUR }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// const url = 'https://min-api.cryptocompare.com/data/pricemulti?fsyms=BTC,ETH&tsyms=USD,EUR'
export default {
  data () {
    return {
      results: {
        BTC: { USD: 3759.91, EUR: 3166.21 },
        ETH: { USD: 281.7, EUR: 236.25 },
        'NEW Currency': { USD: 5.60, EUR: 4.70 }
      }
    }
  }
}
</script>

<style scoped>
@import url('https://cdnjs.cloudflare.com/ajax/libs/foundation/6.3.1/css/foundation.min.css');
</style>
