<template>
  <form @submit.prevent="onSubmit">
    <input v-model="title" type="text">
    <button type="submit">
      Добавить блок
    </button>
  </form>
</template>

<script>
export default {
  data () {
    return {
      title: ''
    }
  },
  methods: {
    onSubmit () {
      if (this.title.trim()) {
        const newTodo = {
          id: Date.now(),
          title: this.title,
          completed: false
        }
        this.$emit('add-todo', newTodo)
        this.title = ''
      }
    }
  }
}
</script>

<style scoped>
form {
  margin-bottom: 10px;
}
button[type="submit"] {
  padding: 2px 10px;
}
</style>
