<template>
  <li>
    <span>
      <input type="checkbox" @change="todo.completed = !todo.completed">
      <strong>{{ index + 1 }}</strong>
      <em :class="{done: todo.completed}">{{ todo.title | uppercase }}</em>
    </span>
    <button class="rm" @click="$emit('remove-todo', todo.id)">
      &times;
    </button>
  </li>
</template>

<script>
export default {
  name: 'TodoItem',
  filters: {
    uppercase (value) {
      return value.toUpperCase()
    }
  },
  props: {
    todo: {
      type: Object,
      required: true
    },
    index: Number
  }
}
</script>

<style scoped>
li {
  border: 1px solid #ccc;
  padding: 10px 15px;
  margin-bottom: 10px;
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: space-between;
  align-items: center;
  align-content: center;
  outline: none!important;
}
li span {
  text-align: left;
  width: calc(100% - 30px);
}
em {
  font-style: normal;
}
.rm {
  width: 30px;
  height: 30px;
  border: none;
  border-radius: 50%;
  color: #fff;
  background-color: #b00;
  font-size: 24px;
  font-weight: 600;
  line-height: 25px;
  text-align: center;
  padding: 0;
  overflow: hidden;
  outline: none;
}
.rm:hover {
  background-color: slategrey;
}
.done {
  text-decoration: line-through;
}
input[type="checkbox"] {
  margin-right: 10px;
}
</style>
