<template>
  <div class="about">
    <div class="container">
      <h1>About Page</h1>
      <img src="/logo.png" alt="Logo">
    </div>
    <input type="text" value="Введи сюда: {{carYear}}">
    <div class="maincontantbox">
      <MainLeftCol />
      <MainCenterCol />
      <MainRightCol />
    </div>
    <div class="container">
      <navbar />
      <h4>Parent: {{ carName }}</h4>
      <count />
      <p>Передача: параметров компоненту, и от дочернего компонента, и функции, связь дочерних компонентов, использование event emitter</p>
      <app-car
        :car-name="carName"
        :car-year="carYear"
        :change-func="changeNameToAudi"
        @nameCanged="carName = $event"
        @counterUpdated="counter = $event"
      />
    </div>
  </div>
</template>

<script>
import Count from 'assets/Count.vue'
import navbar from '~/components/navbar.vue'
import MainLeftCol from '~/components/MainLeftCol.vue'
import MainCenterCol from '~/components/MainCenterCol.vue'
import MainRightCol from '~/components/MainRightCol.vue'

export default {
  components: {
    Count,
    navbar,
    MainLeftCol,
    MainCenterCol,
    MainRightCol
  },
  data () {
    return {
      carName: 'Ford',
      carYear: 2018
    }
  },
  methods: {
    changeNameToAudi () {
      this.carName = 'Audi'
    }
  }
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css?family=Trade+Winds&display=swap');
body {
  font-family: 'Trade Winds', cursive;
}
.about {
  text-align: center;
}
.about h1 {
  margin: 20px 0 30px;
}
.maincontantbox {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: center;
  text-align: left;
  margin: 30px 20px 20px;
}
.maincontantbox > div {
  margin: 0 15px;
  width: 33.333333%;
  border: 1px solid seagreen;
  text-align: center;
  padding: 10px 20px;
}
.maincontantbox > div h3,
.maincontantbox > div p {
  margin: 0 0 5px;
}

nav {
  margin-bottom: 20px;
}
</style>
