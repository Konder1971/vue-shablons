<template>
  <div class="app">
    <Top />
    <Top3 />
    <navbar />
    <div class="container">
      <nuxt />
    </div>
    <Footer />
  </div>
</template>

<script>
import Top from '~/components/Top.vue'
import Top3 from '~/components/Top3.vue'
import Footer from '~/components/Footer.vue'
import navbar from '~/components/navbar.vue'
export default {
  components: {
    navbar, Top, Top3, Footer
  }
}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap');
.app {
  font-family: 'Montserrat', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.app > .container {
  width: 100%!important;
  max-width: 80%!important;
}
hr {
  border-top: 1px solid #2c3e50;
  margin: 0 0 15px;
}
</style>
