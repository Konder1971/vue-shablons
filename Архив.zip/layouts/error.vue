<template>
  <div>
    <h1>Error 404</h1>
    <nuxt-link to="/" tag="button">
      Go to Home
    </nuxt-link>
  </div>
</template>

<style scoped>
button {
  margin-bottom: 30px;
  margin-top: 10px;
}
</style>
