<template>
  <div class="animationslayout">
    <navbar />
    <div class="container">
      <animationssidebar />
      <nuxt />
    </div>
  </div>
</template>

<script>
import navbar from '~/components/navbar.vue'
import animationssidebar from '~/pages/animations/animationssidebar.vue'
export default {
  components: {
    navbar, animationssidebar
  }
}
</script>

<style scoped>
.animationslayout > .container {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
}
.animationssidebar {
  width: 30%;
}
</style>
