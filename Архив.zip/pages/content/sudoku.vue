<template>
  <div class="container">
    <div id="sudoku-demo">
      <h1>Sudoku</h1>
      <button>
        Перемешать
      </button>
    </div>
  </div>
</template>

<script>
export default {
}
</script>

<style scoped>
.container-sudoku {
  display: flex;
  flex-wrap: wrap;
  width: 238px;
  margin-top: 10px;
}
.cell {
  display: flex;
  justify-content: space-around;
  align-items: center;
  width: 25px;
  height: 25px;
  border: 1px solid #aaa;
  margin-right: -1px;
  margin-bottom: -1px;
}
.cell:nth-child(3n) {
  margin-right: 0;
}
.cell:nth-child(27n) {
  margin-bottom: 0;
}
.cell-move {
  transition: transform 1s;
}
</style>
