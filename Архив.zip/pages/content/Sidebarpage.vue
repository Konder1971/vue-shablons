<template>
  <div class="sidebarpage">
    <h2>Sidebar Content</h2>
    <div class="sidebarMenu">
      <ul>
        <nuxt-link
          v-for="link in links"
          :key="link.url"
          tag="li"
          :to="link.url"
          exact="link.exact"
        >
          <a href="#">{{ link.title }}</a>
        </nuxt-link>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Sidebarpage',
  data () {
    return {
      links: [
        { title: 'Content 1', url: 'Content1' },
        { title: 'Content 2', url: 'Content2' },
        { title: 'Content 3', url: 'Content3' },
        { title: 'Таблица умножения', url: 'TablicaUmnojeniay' }
      ]
    }
  }
}
</script>

<style scoped>
  .sidebarpage {
    background-color:#41205f;
    padding: 20px 30px;
  }
  .sidebarpage h2 {
    text-align: center;
    color: #fff;
    font-size: 30px;
    margin-bottom: 15px;
  }
  .sidebarMenu {
    padding: 20px;
    background-color: #000;
  }
  .sidebarpage ul, .sidebarpage li {
    list-style: none;
    padding: 0;
    margin: 0;
    text-align: left
  }
  .sidebarpage li {
    margin-bottom: 10px;
  }
  .sidebarpage a {
    color: #fff;
    font-weight: bold;
    font-size: 20px;
    line-height: normal;
    text-decoration: none;
  }
  .sidebarpage a:hover,
  .sidebarpage li.nuxt-link-exact-active  a {
    color: #42b983;
  }
  .sidebarpage li:last-child {
    margin-bottom: 0;
  }
</style>
