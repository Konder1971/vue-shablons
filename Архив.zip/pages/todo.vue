<template>
  <div class="todoBlock">
    <h1>
      Todo application
    </h1>
    <p>
      Видео тут: <a href="https://www.youtube.com/watch?v=OlnwgS-gk8Y" target="_blank">https://www.youtube.com/watch?v=OlnwgS-gk8Y</a>
      <br>
      Json тут: <a href="https://jsonplaceholder.typicode.com/" target="_blank">https://jsonplaceholder.typicode.com/</a>
    </p>
    <AddTodo
      @add-todo="addTodo"
    />
    <!--
    <select>
      <option value="">
        Сортировать
      </option>
      <option value="all">
        All
      </option>
      <option value="completed">
        Completed
      </option>
      <option value="not-completed">
        Not completed
      </option>
    </select>
    <hr>
    -->
    <Loader v-if="loading" />
    <TodoList
      v-else-if="todos.length"
      :todos="todos"
      @remove-todo="removeTodo"
    />
    <p v-else>
      Нет блоков
    </p>
  </div>
</template>

<script>
import TodoList from '~/components/TodoList'
import AddTodo from '~/components/AddTodo'
import Loader from '~/components/Loader'
export default {
  components: {
    TodoList, AddTodo, Loader
  },
  data () {
    return {
      loading: true,
      todos: [
        // { id: 1, title: 'Хлебопечка сука', completed: false },
        // { id: 2, title: 'Соковыжималка падло', completed: false },
        // { id: 3, title: 'Кофемолка волшебница', completed: false },
        // { id: 4, title: 'Блендер вам нахрен', completed: false },
        // { id: 5, title: 'микроволновка стабильно', completed: false },
        // { id: 6, title: 'электрочайник акуратный', completed: false }
      ]
    }
  },
  mounted () {
    fetch('https://jsonplaceholder.typicode.com/todos?_limit=5')
      .then(response => response.json())
      .then((json) => {
        setTimeout(() => {
          this.todos = json
          this.loading = false
        }, 1000)
      })
  },
  methods: {
    removeTodo (id) {
      this.todos = this.todos.filter(t => t.id !== id)
    },
    addTodo (todo) {
      this.todos.push(todo)
    }
  }
}
</script>

<style scoped>
.todoBlock {
  margin-bottom: 30px;
}
</style>
