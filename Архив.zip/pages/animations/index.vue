<template>
  <div class="container">
    <h1>
      Animations Index Page
    </h1>
    <p>Тута: <a href="https://ru.vuejs.org/v2/guide/transitions.html#%D0%90%D0%BD%D0%B8%D0%BC%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5-%D0%BE%D0%B4%D0%B8%D0%BD%D0%BE%D1%87%D0%BD%D0%BE%D0%B3%D0%BE-%D1%8D%D0%BB%D0%B5%D0%BC%D0%B5%D0%BD%D1%82%D0%B0-%D0%BA%D0%BE%D0%BC%D0%BF%D0%BE%D0%BD%D0%B5%D0%BD%D1%82%D0%B0" target="_blank">Документация</a></p>
    <hr>

    <div class="animeBlock">
      <h4>Переключить отображение блока (есть/нет)</h4>
      <button :class="{ active: active }" @click="show = !show; active = !active">
        Переключить Отображение
      </button>
      <transition name="fade">
        <div v-if="show">
          <div>Блок добавляется/удаляется в Dom</div>
          <h5>Привет! Я Появился</h5>
          <top3 />
        </div>
      </transition>
    </div>

    <div class="animeBlock">
      <h4>CSS-переходы</h4>
      <button :class="{ active: active2 }" @click="show2 = !show2; active2 = !active2">
        Переключить Отрисовку
      </button>
      <transition name="slide-fade">
        <div v-if="show2">
          <h5>Блок добавляется/удаляется в Dom</h5>
          <top />
        </div>
      </transition>
    </div>

    <div class="animeBlock">
      <h4>CSS-анимации</h4>
      <button :class="{ active: active3 }" @click="show3 = !show3; active3 = !active3">
        Переключить Oтображение
      </button>
      <transition name="bounce">
        <div v-if="show3">
          <p>
            Блок добавляется/удаляется в Dom<br>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris facilisis enim libero,
            at lacinia diam fermentum id. Pellentesque habitant morbi tristique senectus et netus.
          </p>
        </div>
      </transition>
    </div>

    <div class="animeBlock">
      <h4>Пользовательские классы переходов</h4>
      <p>
        Вы также можете использовать пользовательские классы переходов, указывая следующие атрибуты:<br>
        enter-class<br>
        enter-active-class
        enter-to-class (в версии 2.1.8+)<br>
        leave-class<br>
        leave-active-class<br>
        leave-to-class (в версии 2.1.8+)<br>
        Таким образом стандартные названия классов будут переопределены, что может быть особенно полезно для комбинирования системы анимированных переходов Vue с возможностями сторонних библиотек CSS-анимаций, таких как Animate.css.
      </p>
      <button :class="{ active: active4 }" @click="show4 = !show4; active4 = !active4">
        Переключить Oтображение
      </button>
      <transition
        name="custom-classes-transition"
        enter-active-class="animated tada"
        leave-active-class="animated bounceOutRight"
      >
        <p v-if="show4">
          Привет с эффектом от Animate.css
        </p>
      </transition>
    </div>
  </div>
</template>

<script>
import Top from '~/components/Top.vue'
import Top3 from '~/components/Top3.vue'
export default {
  components: {
    Top, Top3
  },
  data () {
    return {
      active: false,
      active2: false,
      active3: false,
      active4: false,
      show: false,
      show2: false,
      show3: false,
      show4: false
    }
  }
}
</script>

<style scoped>
@import url('https://cdn.jsdelivr.net/npm/animate.css@3.5.1');
hr {
  margin-bottom: 10px;
}
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 6px 14px 8px;
  margin: 0 10px 10px 0;
  font-size: 16px;
  font-weight: 600;
  outline: none;
}
button:hover,
button.active {
  background-color: #850000;
}
.animeBlock {
  border-bottom: 1px solid #222;
  margin-bottom: 10px;
  padding-bottom: 10px;
}

/* show */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 1.5s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}

/* show2 */
.slide-fade-enter-active {
  transition: all 1s ease;
}
.slide-fade-leave-active {
  transition: all 1s cubic-bezier(1.0, 0.5, 0.8, 1.0);
}
.slide-fade-enter, .slide-fade-leave-to {
  transform: translateX(-10px);
  opacity: 0;
}

/* show3 */
.bounce-enter-active {
  animation: bounce-in 1s;
}
.bounce-leave-active {
  animation: bounce-in 1s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.5);
  }
  100% {
    transform: scale(1);
  }
}
</style>
