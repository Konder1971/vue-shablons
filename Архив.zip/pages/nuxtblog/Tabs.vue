<template>
  <div class="content">
    <h1>Табуляция</h1>
    <hr>

    <div class="tabs">
      <span
        :class="{ active : active_el == 1 }"
        @click="activate(1)"
      >Tab 1</span>
      <span
        :class="{ active : active_el == 2 }"
        @click="activate(2)"
      >Tab 2</span>
      <span
        :class="{ active : active_el == 3 }"
        @click="activate(3)"
      >Tab 3</span>
      <span
        :class="{ active : active_el == 4 }"
        @click="activate(4)"
      >Tab 4</span>
    </div>

    <div class="tabContent">
      <div class="tab1">
        <p>111 111 111</p>
      </div>
      <div class="tab2">
        <p>222 222 222</p>
      </div>
      <div class="tab3">
        <p>333 333 333</p>
      </div>
      <div class="tab4">
        <p>444 444 444</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Tabs',
  data () {
    return {
      active_el: 0
    }
  },
  methods: {
    activate (el) {
      this.active_el = el
    }
  }
}
</script>

<style scoped>
.active {
  color: #850000;
}
</style>
