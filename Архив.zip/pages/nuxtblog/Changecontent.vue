<template>
  <div class="changecontent">
    <h3>Смена отображения контента через v-if</h3>
    <p>v-if стирает элементы из DOM</p>
    <template v-if="isVisible">
      <h3>Header 111 Vis 111</h3>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
        ducimus quidem illo rerum impedit fuga, corrupti dignissimos, maiores quo eos perspiciatis
        ex quasi dolore recusandae beatae consequuntur?
      </p>
    </template>
    <template v-else>
      <h3 style="color: #fff;">
        Header 222 Vis 222
      </h3>
      <p style="color: #fff;">
        Lorem ipsum dolor sit amet consectetur adipisicing elit.
      </p>
    </template>
    <button @click="isVisible = !isVisible">
      Сменить отображения контента
    </button>
    <hr>

    <h3>Смена отображения контента через v-show</h3>
    <p>v-show не стирает элементы из DOM</p>
    <div v-show="isVisibles">
      <h3>Header 333 Vis 333</h3>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
        ducimus quidem illo rerum impedit fuga, corrupti dignissimos, maiores quo eos perspiciatis
        ex quasi dolore recusandae beatae consequuntur?
      </p>
    </div>
    <div v-show="!isVisibles">
      <h3 style="color: #00f;">
        Header 444 Vis 444
      </h3>
      <p style="color: #00f;">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum similique corporis quis
        ducimus quidem illo rerum impedit fuga,
      </p>
    </div>
    <button @click="isVisibles = !isVisibles">
      Сменить отображения контента
    </button>
    <hr>
  </div>
</template>

<script>
export default {
  name: 'Changecontent',
  data () {
    return {
      isVisible: true,
      isVisibles: true
    }
  }
}
</script>

<style scoped>
hr {
  margin: 10px 0;
}
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 10px 14px 12px;
  margin: 14px 10px 10px 0;
  font-size: 18px;
  font-weight: 600;
}
button:hover {
  background-color: #850000;
}
</style>
