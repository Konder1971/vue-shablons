<template>
  <div class="blogsidebar">
    <h2>Vue Shablons</h2>
    <div class="sidebarMenu">
      <nuxt-link
        v-for="link in links"
        :key="link.url"
        tag="li"
        :to="link.url"
        exact="link.exact"
      >
        <a href="#">{{ link.title }}</a>
      </nuxt-link>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Blogsiderbar',
  data () {
    return {
      links: [
        { title: 'Счетчики', url: 'counters' },
        { title: 'Смена отображения контента', url: 'changecontent' },
        { title: 'Замена элементов', url: 'ReplaceItems' },
        { title: 'Работа с классами', url: 'cssclass' },
        { title: 'Списки', url: 'rabotasospiskomblog' },
        { title: 'Формы', url: 'forms' },
        { title: 'Фильтры', url: 'filters' },
        { title: 'Табы', url: 'tabs' },
        { title: 'Варианты меню', url: 'variantmenu' },
        { title: 'Категория 1', url: 'categoty-1' }
      ]
    }
  }
}
</script>

<style scoped>
.blogsidebar {
  background-color: #35495e;
  padding: 20px 30px 30px;
}
.blogsidebar h2 {
  color:#fff;
  text-align: center;
  margin-bottom: 20px
}
.sidebarMenu {
  padding: 25px 20px;
  background-color: #232323;
  border-radius: 4px;
}
.blogsidebar ul,
.blogsidebar li {
  list-style: none;
  padding: 0;
  margin: 0;
}
.blogsidebar li {
  margin-bottom: 15px;
}
.blogsidebar a {
  color: #fff;
  font-weight: bold;
  font-size: 20px;
  text-decoration: none;
}
.blogsidebar a:hover,
.blogsidebar li.nuxt-link-exact-active a {
  color: #F0A829;
}
.blogsidebar li:last-child {
  margin-bottom: 0;
}
</style>
