<template>
  <div class="content">
    <h1>Варианты меню</h1>
    <hr>
    <ul>
      <li
        :class="{ active : active_el == 1 }"
        @click="activate(1)"
      >
        Link 1
      </li>
      <li
        :class="{ active : active_el == 2 }"
        @click="activate(2)"
      >
        Link 2
      </li>
      <li
        :class="{ active : active_el == 3 }"
        @click="activate(3)"
      >
        Link 3
      </li>
    </ul>
    <hr>

    <nav :class="active" @click.prevent>
      <a href="#" class="home" @click="makeActive('home')">Главная</a>
      <a href="#" class="projects" @click="makeActive('projects')">Проекты</a>
      <a href="#" class="services" @click="makeActive('services')">Услуги</a>
      <a href="#" class="contact" @click="makeActive('contact')">Контакты</a>
    </nav>
    <p class="nav-p">
      Активный класс <b>{{ active }}</b>
    </p>
    <hr>
  </div>
</template>

<script>
export default {
  name: 'Variantmenu',
  data () {
    return {
      active_el: 0,
      active: 'home'
    }
  },
  methods: {
    activate (el) {
      this.active_el = el
    },
    makeActive (item) {
      this.active = item
    }
  }
}
</script>

<style scoped>
ul > li {
  color: darkgreen;
}
ul > li:hover {
  cursor: pointer;
  text-decoration: underline;
}
.active {
  color: #850000;
}
a,
a:visited {
  outline: none;
  color: #389dc1;
}
a:hover {
  text-decoration: none;
}
nav {
  display: inline-block;
  background-color: #5597b4;
  padding: 0;
  margin-bottom: 10px;
}
nav a {
  display: inline-block;
  float: left;
  padding: 18px 30px;
  color: #fff !important;
  font-weight: bold;
  font-size: 16px;
  text-decoration: none !important;
  line-height: 1;
  text-transform: uppercase;
  background-color: transparent;
  -webkit-transition: background-color 0.25s;
  -moz-transition: background-color 0.25s;
  transition: background-color 0.25s;
}
nav.home .home,
nav.projects .projects,
nav.services .services,
nav.contact .contact,
nav .home:hover,
nav .projects:hover,
nav .services:hover,
nav .contact:hover {
  background-color: #e35885;
}
p.nav-p {
  color: #222;
}
p.nav-p b {
  color: #000;
  display: inline-block;
  padding: 5px 12px;
  background-color: #fff;
  font-weight: normal;
}
</style>
