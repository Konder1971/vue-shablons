<template>
  <div class="mainrightcol">
    <h3>Main Right Col</h3>
    <p>
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aspernatur dolore voluptate, ab sed, consectetur provident aperiam obcaecati quis reiciendis nemo id facilis aut.
    </p>
    <div>
      <nuxt-link to="/technologies">
        Technologies
      </nuxt-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MainRightCol'
}
</script>
