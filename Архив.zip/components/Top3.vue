<template>
  <div class="top3">
    top 3<br>
    <nuxt-link to="/">
      <img
        alt=""
        src="~/assets/logo.png"
      >
    </nuxt-link>
  </div>
</template>
<script>
export default {
  name: 'Top3'
}
</script>
<style scoped>
.top3 {
  background-color: #41205f;
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  position: -webkit-sticky;
  position: sticky;
  top: 0;
  padding: 12px 0;
  text-align: center;
}
.top3 img {
  width: 60px;
  margin-top: 10px;
}
</style>
