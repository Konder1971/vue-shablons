<template>
  <div class="maincentercol">
    <h3>Main Center Col</h3>
    <p>
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur minus assumenda architecto. Quis, magnam culpa. Provident harum eligendi, reiciendis accusamus hic mollitia earum quas explicabo repellendus reprehenderit! Perferendis, nulla facilis?
    </p>
  </div>
</template>

<script>
export default {
  name: 'MainCenterCol',
  head () {
    return {
      script: [
        {
          src:
            'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'
        }
      ],
      link: [
        {
          rel: 'stylesheet',
          href:
            'https://fonts.googleapis.com/css?family=Trade+Winds&display=swap'
        }
      ]
    }
  }
}
</script>

<style>
body {
  font-family: 'Trade Winds', cursive;
}
</style>
