<template>
  <div class="counterblock">
    <p>Counter: {{ count }}</p>
    <button @click="countPlus">
      Add counter
    </button>
    <button @click="countMinus">
      Reduce counter
    </button>
    <button @click="countReset">
      Reset counter
    </button>
    <button @click="countClear">
      Clear counter
    </button>
  </div>
</template>

<script>
export default {
  name: 'Counterblock',
  data () {
    return {
      count: 0
    }
  },
  methods: {
    countPlus () {
      this.count++
    },
    countMinus () {
      this.count--
    },
    countReset () {
      this.count = 0
    },
    countClear () {
      this.count = ''
    }
  }
}
</script>

<style scoped>
</style>
