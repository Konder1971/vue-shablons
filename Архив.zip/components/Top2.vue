<template>
  <div class="top2">
    top 2
  </div>
</template>
<script>
export default {
  name: 'Top2'
}
</script>

<style scoped>
.top2 {
  background-color: #232323;
  color: #fff;
  height: 45px;
  line-height: 45px;
  font-size: 13px;
  text-align: center;
}
</style>
