<template>
  <div class="top">
    top 5375 4115 0032 3808
  </div>
</template>

<script>
export default {
  name: 'Top'
}
</script>

<style scoped>
.top {
  background-color: #000;
  background-image: linear-gradient(to right, #35495e, #35495e 50%, #4fc08d 50%);
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  text-align: center;
  padding: 7px 10px 5px 10px;
}
.top:hover {
  background-image: linear-gradient(to right, #4fc08d, #4fc08d 50%, #35495e 50%);
  transition: width 0.15s ease-out 0.1s;
  transition: width 0.15s ease-in;
}
</style>
