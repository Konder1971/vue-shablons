<template>
  <div class="top">
    top 5375 4115 0032 3808
  </div>
</template>

<script>
export default {
  name: 'Top'
}
</script>

<style scoped>
.top {
  background-color: #000;
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  text-align: center;
  padding: 3px 0 5px;
}
</style>
